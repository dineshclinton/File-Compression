﻿using DataStructureForCompression;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace FileCompress.BusinessLayer
{
    public class TextCompression<TOutput> : IFileCompress<string, TOutput>
    {
        private readonly string _inFilePath;
        private readonly string _outFilePath;
        private readonly ICompress<string, TOutput> _algo;
        private Encoding _enc;

        private TOutput _output;

        public TextCompression(string filePath, string outfilePath, ICompress<string, TOutput> algo)
        {
            _inFilePath = filePath;
            _outFilePath = outfilePath;
            _algo = algo;
        }
        public async Task<TOutput> CompressAsync()
        {
            using (StreamReader sr = new StreamReader(_inFilePath, true))
            {
                //Test for the encoding after reading, or at least
                //after the first read.
                _enc = sr.CurrentEncoding;
            }
            var task = await File.ReadAllTextAsync(_inFilePath);
            _output = _algo.Encode(task);
            return _output;
        }

        public async Task<String> DeCompressAsync()
        {
            string decompressedText = _algo.Decode(_output);
            await File.WriteAllTextAsync(_outFilePath, decompressedText,_enc);

            return decompressedText;
        }
    }
}
