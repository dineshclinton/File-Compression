﻿using DataStructureForCompression.Huffman.HuffmanCustomizedStringCompression;
using FileCompress;
using FileCompress.BusinessLayer;
using System;
using System.Collections;
using System.IO;

namespace FileCompression
{
    class Program
    {
        static void Main(string[] args)
        {
            string _inFilePath = @"C:\Users\dinesh.clinton\Downloads\TestFile.txt";
            string _outFilePath = @"C:\Users\dinesh.clinton\Downloads\OutTextFile.txt";

            FileInfo _infi = new FileInfo(_inFilePath);
            
            Console.WriteLine("Input File Size\t\t: " + _infi.Length + " Bytes");

            //string _compressedFilePath = @"C:\Users\dinesh.clinton\Downloads\CompressedTextFile.txt";
            //var huffmanTreeStringBased = new HuffmanTreeCustomizedString();
            var huffmanTreeStringBased = new HuffmanTreeCustomizedStringOptimized();
            var fileCompress = new TextCompression<BitArray>(_inFilePath, _outFilePath, huffmanTreeStringBased);

            var watch = new System.Diagnostics.Stopwatch();

            watch.Start();


            // Compressing the file
            var compressedFile = fileCompress.CompressAsync().GetAwaiter().GetResult();

            watch.Stop();

            Console.WriteLine($"Compression Execution Time: {watch.ElapsedMilliseconds} ms");

            Console.WriteLine("Compressed File Size\t: " + (float)compressedFile.Length/8 + " Bytes");

            // UnCompressing the file
            var decompressedFile = fileCompress.DeCompressAsync().GetAwaiter().GetResult();

            FileInfo _opFi = new FileInfo(_inFilePath);

            Console.WriteLine("Output File Size\t: " + _opFi.Length + " Bytes");
        }
    }
}
