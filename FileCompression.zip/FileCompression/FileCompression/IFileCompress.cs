﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace FileCompress
{
    interface IFileCompress<TInput, TOutput>
    {
        Task<TOutput> CompressAsync();

        Task<TInput> DeCompressAsync();
    }
}
