﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataStructureForCompression.Huffman.HuffmanCustomizedStringCompression
{
    public class HuffmanTreeCustomizedString : ICompress<string, BitArray>
    {
        protected List<Node> node = new List<Node>();
        public Node rootNode { get; set; }
        public Dictionary<string, int> frequency = new Dictionary<string, int>();

        // build the huffman tree of the input file
        private void Build_Tree(string input)
        {
            var splitInputBySpace = input.Split(' ');
            for (int i = 0; i < splitInputBySpace.Length; i++)
            {
                // check the tree contains string or not
                if (!frequency.ContainsKey(splitInputBySpace[i]))
                {
                    // add the string in tree
                    frequency.Add(splitInputBySpace[i], 0);
                }

                frequency[splitInputBySpace[i]]++;
            }

            foreach (KeyValuePair<string, int> symbol in frequency)
            {
                node.Add(new Node() { literal = symbol.Key, frequency = symbol.Value });
            }

            while (node.Count > 1)
            {
                // ordering the nodes on the basis of frequency
                List<Node> orderedNodes = node.OrderBy(node => node.frequency).ToList<Node>();

                if (orderedNodes.Count >= 2)
                {
                    // Take first two items
                    List<Node> takenNode = orderedNodes.Take(2).ToList<Node>();

                    // Create a parent node by combining the frequencies
                    Node parent = new Node()
                    {
                        literal = null,
                        frequency = takenNode[0].frequency + takenNode[1].frequency,
                        leftNode = takenNode[0],
                        rightNode = takenNode[1]
                    };

                    node.Remove(takenNode[0]);
                    node.Remove(takenNode[1]);
                    node.Add(parent);
                }

                this.rootNode = node.FirstOrDefault();

            }

        }

        // Encode function for encoding the String in binary form
        public virtual BitArray Encode(string input)
        {
            var splitInputBySpace = input.Split(' ');

            List<bool> encodedInput = new List<bool>();

            for (int i = 0; i < splitInputBySpace.Length; i++)
            {
                List<bool> encodedString = this.rootNode.Traverse_Tree(splitInputBySpace[i], new List<bool>());
                encodedInput.AddRange(encodedString);
            }

            BitArray BitArray = new BitArray(encodedInput.ToArray());

            return BitArray;
        }

        public virtual string Decode(BitArray BitArray)
        {
            Node currentNode = this.rootNode;
            string decoded = "";

            foreach (bool bit in BitArray)
            {
                if (bit)
                {
                    if (currentNode.rightNode != null)
                    {
                        currentNode = currentNode.rightNode;
                    }
                }
                else
                {
                    if (currentNode.leftNode != null)
                    {
                        currentNode = currentNode.leftNode;
                    }
                }

                if (IsLeaf(currentNode))
                {
                    decoded += currentNode.literal;
                    currentNode = this.rootNode;
                }
            }

            return decoded;
        }

        public bool IsLeaf(Node node)
        {

            return (node.leftNode == null && node.rightNode == null);

        }

    }
}
