﻿using DataStructureForCompression.Extensions;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataStructureForCompression.Huffman.HuffmanCustomizedStringCompression
{
    public class HuffmanTreeCustomizedStringOptimized : HuffmanTreeCustomizedString
    {

        // build the huffman tree of the input file
        public void Build_Tree(string [] splitInputbySpace)
        {
            var watch = new System.Diagnostics.Stopwatch();

            watch.Start();


            for (int i = 0; i < splitInputbySpace.Length; i++)
            {
                // check the tree contains string or not
                if (!frequency.ContainsKey(splitInputbySpace[i]))
                {
                    // add the string in tree
                    frequency.Add(splitInputbySpace[i], 0);
                }

                frequency[splitInputbySpace[i]]++;
            }

            watch.Stop();

            Console.WriteLine($"Data dictionary generation: {watch.ElapsedMilliseconds} ms");

            watch.Restart();

            // Using a Min Heap to store and access the frequency in ascending order
            SortedDictionary<int, LinkedList<Node>> freqInverted = new SortedDictionary<int, LinkedList<Node>>(AsInverted(frequency));

            watch.Stop();

            Console.WriteLine($"Data dictionary Inversion: {watch.ElapsedMilliseconds} ms");

            watch.Restart();

            // This Min Heap is used for creating the tree
            while (freqInverted.Count > 0)
            {
                var takenNode1 = freqInverted.FirstOrDefault();
                Node key1 = takenNode1.Value.First.Value;

                takenNode1.Value.RemoveFirst();

                if (takenNode1.Value.Count == 0)
                {
                    freqInverted.Remove(takenNode1.Key);
                }

                var takenNode2 = freqInverted.FirstOrDefault();

                if (freqInverted.Count > 0)
                {
                    Node key2 = takenNode2.Value.First.Value;
                    takenNode2.Value.RemoveFirst();

                    if (takenNode2.Value.Count == 0)
                    {
                        freqInverted.Remove(takenNode2.Key);
                    }

                    Node parent = new Node()
                    {
                        literal = null,
                        frequency = takenNode1.Key + takenNode2.Key,
                        leftNode = key1,
                        rightNode = key2
                    };

                    if (!freqInverted.ContainsKey(parent.frequency))
                    {
                        var l = new LinkedList<Node>();
                        l.AddFirst(parent);
                        freqInverted.Add(parent.frequency, l);
                    }
                    else
                    {
                        freqInverted[parent.frequency].AddFirst(parent);
                    }


                    this.rootNode = parent;

                }

            }

            watch.Stop();

            Console.WriteLine($"Heap Parse dictionary: {watch.ElapsedMilliseconds} ms");

            watch.Restart();

            watch.Stop();

            Console.WriteLine($"Node Parse dictionary: {watch.ElapsedMilliseconds} ms");

            watch.Restart();
        }

        public Dictionary<int, LinkedList<Node>> AsInverted(Dictionary<string, int> source)
        {
            var inverted = new Dictionary<int, LinkedList<Node>>();

            foreach (KeyValuePair<string, int> item in source)
            {
                var newNode = new Node() { literal = item.Key, frequency = item.Value };
                node.Add(newNode);

                if (!inverted.ContainsKey(item.Value))
                {
                    var l = new LinkedList<Node>();
                    l.AddFirst(newNode);
                    inverted.Add(item.Value, l);
                }
                else
                {
                    inverted[item.Value].AddFirst(newNode);
                }
            }

            return inverted;
        }

        public override BitArray Encode(string input)
        {
            var watch = new System.Diagnostics.Stopwatch();

            watch.Start();

            Console.WriteLine($"Encoding Starts: {watch.ElapsedMilliseconds} ms");

            var splitInputbySpace = input.Split(' ');
            
            // Build tree
            Build_Tree(splitInputbySpace);

            List<bool> encodedInput = new List<bool>();


            // Get the rootnode
            var node = this.rootNode;

            Console.WriteLine($"Tree Build Complete, Traversing and Creating LookUp: {watch.ElapsedMilliseconds} ms");

            // Create a Lookup by traversing the tree once
            node.Traverse_Tree_And_Create_LookUp(new LinkedList<bool>());

            Console.WriteLine($"Traversing and Creating LookUp Complete: {watch.ElapsedMilliseconds} ms");

            
            // Generate Encoded input
            foreach (var item in splitInputbySpace)
            {
                LinkedList<bool> encodedString = Node.dict[item];
                encodedInput.AddRange(encodedString);
            }

            Console.WriteLine($"Enconding the string based on the lookup is complete: {watch.ElapsedMilliseconds} ms");

            BitArray BitArray = new BitArray(encodedInput.ToArray());

            watch.Stop();

            Console.WriteLine($"Encoding Completed: {watch.ElapsedMilliseconds} ms");

            return BitArray;
        }

        public override string Decode(BitArray BitArray)
        {
            var watch = new System.Diagnostics.Stopwatch();

            watch.Start();

            Console.WriteLine($"Decoding Starts: {watch.ElapsedMilliseconds} ms");

            Node currentNode = this.rootNode;
            StringBuilder decoded = new StringBuilder();

            var b = new bool[BitArray.Length];

            BitArray.CopyTo(b, 0);


            var gr = Node.dict.GroupBy(x => x.Value.Count);

            IEqualityComparer<bool[]> tex = ArrayEqualityComparer<bool>.Default;

            // Invert the lookup dictionary by changing Keys as Values and Values as Keys
            var res = Node.dict
                    .ToDictionary(g => g.Value.ToArray(), g => g.Key, tex);
            int i = 0;

            var list = gr.Select(x => x.Key).OrderBy(x => x).ToList();


            while (i < b.Length)
            {
                foreach (var item in list)
                {
                    bool[] result = new bool[item];
                    Array.Copy(b, i, result, 0, item);

                    if (res.ContainsKey(result))
                    {
                        decoded.Append(res[result]);
                        i += item;
                        if (i < b.Length)
                        {
                            decoded.Append(" ");
                        }
                        
                        break;
                    }

                }


            }

            watch.Stop();

            Console.WriteLine($"Decoding Completed: {watch.ElapsedMilliseconds} ms");

            return decoded.ToString();

        }
    }



}