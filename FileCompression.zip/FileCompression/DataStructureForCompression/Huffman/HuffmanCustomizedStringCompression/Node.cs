﻿using DataStructureForCompression.Extensions;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataStructureForCompression.Huffman.HuffmanCustomizedStringCompression
{
    public class Node
    {
        public string literal { get; set; }
        public int frequency { get; set; }
        public Node rightNode { get; set; }
        public Node leftNode { get; set; }
        public static Dictionary<string, LinkedList<bool>> dict = new Dictionary<string, LinkedList<bool>>();

        public List<bool> Traverse_Tree(string symbol, List<bool> data)
        {
            // Leaf
            if (rightNode == null && leftNode == null)
            {
                if (symbol.Equals(this.literal))
                {
                    return data;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                List<bool> left = null;
                List<bool> right = null;

                if (leftNode != null)
                {
                    List<bool> leftPath = new List<bool>();
                    leftPath.AddRange(data);
                    leftPath.Add(false);

                    left = leftNode.Traverse_Tree(symbol, leftPath);
                }

                if (rightNode != null)
                {
                    List<bool> rightPath = new List<bool>();
                    rightPath.AddRange(data);
                    rightPath.Add(true);
                    right = rightNode.Traverse_Tree(symbol, rightPath);
                }

                if (left != null)
                {
                    return left;
                }
                else
                {
                    return right;
                }
            }
        }

        public LinkedList<bool> Traverse_Tree_And_Create_LookUp(LinkedList<bool> data)
        {
            // Leaf
            if (rightNode == null && leftNode == null)
            {
                if (this.literal != null)
                {
                    dict.Add(this.literal, data);
                }
                //else
                //{
                    return null;
                //}
            }
            else
            {
                LinkedList<bool> left = null;
                LinkedList<bool> right = null;

                if (leftNode != null)
                {
                    LinkedList<bool> leftPath = new LinkedList<bool>();
                    leftPath.AppendRange(data);
                    leftPath.AddLast(false);

                    left = leftNode.Traverse_Tree_And_Create_LookUp(leftPath);
                }

                if (rightNode != null)
                {
                    LinkedList<bool> rightPath = new LinkedList<bool>();
                    rightPath.AppendRange(data);
                    rightPath.AddLast(true);
                    right = rightNode.Traverse_Tree_And_Create_LookUp(rightPath);
                }

                if (left != null)
                {
                    return left;
                }
                else
                {
                    return right;
                }
            }
        }

    }
}
