﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace DataStructureForCompression
{
    public interface ICompress<TInput, TOutput>
    {
        TOutput Encode(TInput input);

        TInput Decode(TOutput input);
    }
}
